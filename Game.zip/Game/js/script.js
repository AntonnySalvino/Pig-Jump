//  A principal diferença entre elas é que setTimeout executa o código uma vez após um determinado tempo, 
// enquanto setInterval executa o código repetidamente em intervalos de tempo regulares.
//Por exemplo, se você quiser exibir uma mensagem na tela após 5 segundos, você pode usar setTimeout da seguinte forma:

// setTimeout(function() {
//   console.log("Passaram-se 5 segundos!");
// }, 5000);

// Por outro lado, se você quiser exibir uma mensagem na tela a cada 5 segundos, você pode usar setInterval da seguinte forma:


// setInterval(function() {
//   console.log("Passaram-se 5 segundos!");
// }, 5000);
function playGame() {
  var interface = document.getElementById('interface');
  var jogo = document.getElementById('jogo')
  var musica = document.getElementById("myAudio");

  jogo.style.display = 'block';
  interface.style.display = 'none';
  musica.play();
  
  function jump() {
    const pig = document.getElementById("pig")
    pig.classList.add("jump")
    setTimeout(() => {            
        pig.classList.remove("jump")

    }, 500); // função que demora 500ms para ser executada, e é executada apenas uma vez
}

document.addEventListener('keydown', jump) // Ao apertar uma tela o boneco pula

    // Pontuação
      
    const pontuacao = document.getElementById("pontuacao");
    let intervalId;
    let contador = 0;

    intervalId = setInterval(() => {
      contador++;
      const numeroFormatado = String(contador).padStart(5, '0');
      pontuacao.textContent = numeroFormatado;
      if (contador >= 100  ) {
        const container = document.querySelector('.container');
        const sol = document.getElementById('sol');
        const lua = document.getElementById('lua');
        sol.style.display = 'none';
        lua.style.display = 'block';
        container.style.backgroundImage = "linear-gradient(to bottom, #000000, #070070)";
        
        
      }
      
    }, 100);
    

function gameover() {
          var bucket = document.getElementById('bucket');
          var posicao_esquerda_bucket = bucket.offsetLeft;
          var valorbottom_pig = +window.getComputedStyle(pig).bottom.replace('px' , ''); 
          // a variavel consulta o bottom de "pig", ao verifica-la é mostrada uma string com o valor, por exemplo "87px",
          // o método replace pega esse px e substitui por nada, faltando apenas converter a string em inteiro
          // O sinal de "+" serve para converter uma string em um inteiro.

          if (posicao_esquerda_bucket <= 75 && posicao_esquerda_bucket >= 0 && valorbottom_pig < 70) {
            bucket.style.animation = 'none';
            bucket.style.left  = `${posicao_esquerda_bucket}px`; // utilizado para quando o boneco morrer ele parar no lugar onde aconteceu a morte

            var nuvem = document.getElementById("nuvem")
            var posicao_esquerda_nuvem = nuvem.offsetLeft;
            nuvem.style.left  = `${posicao_esquerda_nuvem}px`;
            nuvem.style.animation = 'none';

            pig.style.animation = 'none';
            pig.style.bottom  = `${valorbottom_pig}px`;
            pig.src = "https://media.tenor.com/tSAFsCOiZMcAAAAj/butata-pig.gif";

            clearInterval(intervalId); 
            

            //https://tenor.com/pt-BR/view/bucket-hide-billy-srgrafo-chill-gif-21208393
            

}
}
        const verifica_gameover = setInterval(gameover, 1); // a cada ms verifica continuamente se o porco morreu

        
        // Esse trecho do código tem a função de aumentar a dificuldade do jogo a cada de vez que o boneco passa

          setInterval(() => {
            var computedStyle = window.getComputedStyle(bucket);
            var animationDuration = computedStyle.getPropertyValue("animation-duration");
            var animationDurationInSeconds = parseFloat(animationDuration);
            var posicaoleft = bucket.offsetLeft;
            if (posicaoleft < 0 ) {
                var aumentarvelocidade = animationDurationInSeconds * 0.999;
                bucket.style.animationDuration = `${aumentarvelocidade}s`;
                
  
            }
        }, 1);
          
        // Esse trecho do código tem a função de citar a pontuação do usuario 



}

